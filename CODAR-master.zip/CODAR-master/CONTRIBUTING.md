
# Contributing to CODAR


As an open source project, CODAR welcomes contributions of many forms.

Examples of contributions include:

* Code patches
* Documentation improvements
* Bug reports and patch reviews

Code of Conduct
===============

As a contributor, you can help us keep the community open and inclusive.
Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md).
