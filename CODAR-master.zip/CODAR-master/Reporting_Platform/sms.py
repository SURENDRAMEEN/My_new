#!/usr/bin/python3
"""
All functions related to SMS go here
"""
# Push Data for SMS into the database
def get_data_sms(sender_number):
    """ Push Data for sms into the database
    """
    sms_data = ''
    return sms_data
